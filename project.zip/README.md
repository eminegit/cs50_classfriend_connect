ClassFriend Connect

Overview:

ClassFriend Connect is a web application designed to simplify playdate arrangements for elementary and middle school students (up to grade 8). It provides a safe and user-friendly platform for parents to connect, schedule playdates, and discover events within their school community.

Key features:
1) Parent registration and sign-in: Parents can create accounts and access the platform.
    a) Register
    b) Sign In

2) School pages: Dedicated pages for each participating school allow parents to connect with other parents, view student and parents information, and schedule playdates.
    a) Goodyear Elementary School
    b) Hurl-Wyman Elementary School
    c) Malcolm White Elementary School
    d) Shamrock Elementary

3) Event creation and listing: Parents can create and manage events for their child's school, such as playdates, parties, or group activities.

Technical details:

1) Development stack:
    Backend/Programming language: Flask (Python)
    Database: SQLite3
    Frontend: HTML, CSS
2) Dependencies:
    Python libraries: sqlite3
3) File structure:
    data/: Database file friends_database.db (stores parent, student, passcode, and event tables)
    static/: Pictures and styles.css
    templates/: HTML pages (index, about, contacts, register, signin, school-specific pages)
    app.py: Main Python script running the application
    design.md: Design documentation
    readme.md: Application documentation
    requirement.txt: List of required Python libraries

How to use:

1) Parents can register on the platform using their child's Teacher name and Registration Passcode: (I could not get this feature to work!)
2) Once registered, parents can access their child's school page and view information about other students and parents.
3) Parents can contact other parents directly to schedule playdates or participate in listed events.
4) Parents can also create and manage their own events on the school page.

Benefits:

1) Simplifies playdate arrangements: ClassFriend Connect helps the playdate planning process for busy parents.
2) Provides a safe and secure environment: The platform is designed with user privacy and security in mind. (I could not get this feature to work!)
3) Fosters community connections: Parents can connect with other parents within their school community.
4) Encourages student interaction: Playdates and events provide opportunities for students to socialize and build friendships.


Requirements:
Before running the project, make sure you have the following installed:
1) Python 3
2) Flask
3) SQLite3

Run the Flask Application
flask run
the application will run on the local host http://127.0.0.1:5000 or http://localhost:5000


For any quesstions please contact 'emine.dogan@gmail.com'