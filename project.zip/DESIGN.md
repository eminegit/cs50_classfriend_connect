Design Overview:

Project Structure - The main components of ClassFriend Connect are as follows:


classfriendconnect/
|-- data/
| |-- friends_database.db
|-- static/
| |-- friendslogo.jpeg/
| |-- goodyear.jpeg
| |-- hurld.jpeg
| |-- kids.jpeg
| |-- malcolm-white.jpeg
| |-- shamrock.jpeg
| |-- sky1.jpeg
| |-- styles.css
|-- templates/
| |-- index.html
| |-- about.html
| |-- contacts.html
| |-- register.html
| |-- signin.html
| |-- goodyear.html
| |-- hurld.html
| |-- malcomlwhite.html
| |-- shamrock.html
|-- app.py
|-- design.md
|-- readme.md
|-- requirement.txt


1. data/
   - Contains the SQLite database file friends_database.db.
   - Database tables include Parent, Student, Passcode, and Events.

2. static/
   - Contains images and includes the styles.css file for styling the web pages.

3. templates/
   - Contains HTML templates for different pages:
     - index.html: Home page.
     - about.html: About page.
     - contacts.html: Contact page.
     - register.html: User registration page.
     - signin.html`: User sign-in page.
     - goodyear.html, hurld.html, malcomlwhite.html, shamrock.html: School-specific pages.

4. app.py
   - The main Python file responsible for handling routes and controlling the application's logic.

Database Schema

The database, friends_database.db, consists of the following tables:

1. Parent` Table:
   - Fields: parent_id, username, password, email

2. Student Table:
   - Fields: student_id, parent_id, student_name

3. Passcode Table:
   - Fields: passcode_id, passcode`, teacher

4. Events Table:
   - Fields: event_id, event_name, description, date, location

Frontend

The HTML templates define the structure of the pages, and the styling is managed through the styles.css file.

Backend

The backend is implemented in Python using the Flask framework. It handles user authentication, ( I could not get this to work!) database interactions, and route management.

Usage

Before running the project, make sure you have the following installed:
1) Python 3
2) Flask
3) SQLite3

Run the Flask Application
flask run
the application will run on the local host http://127.0.0.1:5000 or http://localhost:5000


For any quesstions please contact 'emine.dogan@gmail.com'





