from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)
app.template_folder = os.path.abspath('templates')
app.static_folder = os.path.abspath('static')

# Function to establish a connection to the SQLite database
def connect_db():
    db_path = os.path.join('data', 'friends_database.db')
    return sqlite3.connect(db_path)

current_date = datetime.now().strftime('%Y-%m-%d')

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contacts")
def contacts():
    return render_template("contacts.html")


@app.route("/validate_passcode", methods=['POST'])
def validate_passcode():
    teacher_name = request.form['studentTeacher']
    passcode = request.form['registrationpasscode']

    print(f"Received data - Teacher: {teacher_name}, Passcode: {passcode}")

    valid = is_valid_passcode(teacher_name, passcode)

    print(f"Valid: {valid}")

    return jsonify(valid=valid)

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Extracting data from the form
        registration_passcode = request.form['registrationpasscode']

        parent_first_last_name = request.form['parentFirstLastName']
        parent_email = request.form['parentemail']
        parent_password = request.form['createpassword']
        parent_phone_number_raw = request.form['parentphonenumber']
        parent_phone_number_formatted = format_phone_number(parent_phone_number_raw)

        student_first_last_name = request.form['studentFirstLastName']
        student_school = request.form['studentSchool']
        student_grade = request.form['studentGrade']
        student_teacher = request.form['studentTeacher']
        student_interests = request.form['studentInterests']


        # Saving data to the Parent table
        with connect_db() as con:
            cur = con.cursor()
            cur.execute('INSERT INTO Parent (first_last_name, email, password, phone_number) VALUES (?, ?, ?, ?)',
                        (parent_first_last_name, parent_email, parent_password, parent_phone_number_formatted))
            parent_id = cur.lastrowid

        # Saving data to the Student table
        with connect_db() as con:
            cur = con.cursor()
            cur.execute('INSERT INTO Student (parent_id, first_last_name, school, grade, teacher, interests) '
                        'VALUES (?, ?, ?, ?, ?, ?)',
                        (parent_id, student_first_last_name, student_school, student_grade, student_teacher,
                         student_interests))

        # Generate the corresponding HTML page based on the selected school
        school_html_mapping = {
            'Goodyear Elementary School': 'goodyear',
            'Hurld Wyman Elementary': 'hurld',
            'Malcolm White Elementary School': 'malcolmwhite',
            'Shamrock Elementary School': 'shamrock',
        }

        selected_school_html = school_html_mapping.get(student_school)

        if selected_school_html:
            return redirect(url_for(selected_school_html))
        else:
            # Redirect to the homepage if selected school doesn't have a corresponding HTML page
            return redirect(url_for('index'))

    return render_template("register.html")

def format_phone_number(raw_number):
    # Function to format the phone number as (xxx) xxx-xxxx
    formatted_number = raw_number.replace('(', '').replace(')', '').replace(' ', '').replace('-', '')
    return f'({formatted_number[:3]}) {formatted_number[3:6]}-{formatted_number[6:]}'

@app.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "POST":
        email = request.form.get("parentemail")
        password = request.form.get("password")

        connection = connect_db()
        cursor = connection.cursor()

        # Use a parameterized query to avoid SQL injection
        query = "SELECT Student.school FROM Parent JOIN Student ON Parent.id = Student.parent_id " \
                "WHERE Parent.email = ? AND Parent.password = ?"
        cursor.execute(query, (email, password))
        school = cursor.fetchone()

        # Close the database connection
        connection.close()

        if school:
            print("Schoolfrom line 172:", school[0])
            print("School:", school[0])
            # Map the school name to the corresponding HTML endpoint
            school_html_mapping = {
                'Goodyear Elementary School': 'goodyear',
                'Hurld Wyman Elementary': 'hurld',
                'Malcolm White Elementary School': 'malcolmwhite',
                'Shamrock Elementary School': 'shamrock',
            }
            print("Second School:", school[0])

            selected_school_html = school_html_mapping.get(school[0])
            print("selected_school_html:", selected_school_html)
            if selected_school_html:
                return redirect(url_for(selected_school_html))

        # Redirect to a default page if the school is not found or if there's an issue
        return redirect(url_for('default_page'))

    # Handle the case when the request method is GET (display the form or handle it accordingly)
    return render_template('signin.html')

@app.route("/default_page")
def default_page():
    # Handle the case when the school is not found or if there's an issue
    return "School not found or there was an issue with the login credentials"

@app.route("/goodyear.html")
def goodyear():
    # Fetch student and parent data for Goodyear Elementary School
    with connect_db() as con:
        cur = con.cursor()
        cur.execute('''
            SELECT s.first_last_name AS student_name, s.interests AS student_interests,
                   s.grade AS student_grade, s.teacher AS student_teacher, s.school AS student_school,
                   p.first_last_name AS parent_name, p.email AS parent_email, p.phone_number AS parent_phone
            FROM Student s
            JOIN Parent p ON s.parent_id = p.id
            WHERE s.school = ?
        ''', ('Goodyear Elementary School',))
        goodyear_data = cur.fetchall()

    # Fetch events information to goodyear.html
        cur.execute('''
            SELECT id, name, date, time, location, creator
            FROM events
            WHERE school = ? AND DATE(date) >= ?
        ''', ('Goodyear Elementary School', current_date))
        goodyear_events = cur.fetchall()
    # Send information for displaying in goodyear.html
    return render_template("goodyear.html", data=goodyear_data, events=goodyear_events)

@app.route("/hurld.html")
def hurld():
    # Fetch student and parent data for Hurld Wyman Elementary School
    with connect_db() as con:
        cur = con.cursor()
        cur.execute('''
            SELECT s.first_last_name AS student_name, s.interests AS student_interests,
                   s.grade AS student_grade, s.teacher AS student_teacher, s.school AS student_school,
                   p.first_last_name AS parent_name, p.email AS parent_email, p.phone_number AS parent_phone
            FROM Student s
            JOIN Parent p ON s.parent_id = p.id
            WHERE s.school = ?
        ''', ('Hurld Wyman Elementary',))
        hurld_data = cur.fetchall()

        # Fetch events information for Hurld Wyman Elementary School
        cur.execute('''
            SELECT id, name, date, time, location, creator
            FROM events
            WHERE school = ? AND DATE(date) >= ?
        ''', ('Hurld Wyman Elementary', current_date))
        hurld_events = cur.fetchall()
    # Send information for displaying in hurld.html
    return render_template("hurld.html", data=hurld_data, events=hurld_events)


@app.route("/malcolm-white.html")
def malcolmwhite():
    # Fetch student and parent data for Malcolm White Elementary School
    with connect_db() as con:
        cur = con.cursor()
        cur.execute('''
            SELECT s.first_last_name AS student_name, s.interests AS student_interests,
                   s.grade AS student_grade, s.teacher AS student_teacher, s.school AS student_school,
                   p.first_last_name AS parent_name, p.email AS parent_email, p.phone_number AS parent_phone
            FROM Student s
            JOIN Parent p ON s.parent_id = p.id
            WHERE s.school = ?
        ''', ('Malcolm White Elementary School',))
        malcolmwhite_data = cur.fetchall()
        # Fetch events information for Malcolm White Elementary School
        cur.execute('''
            SELECT id, name, date, time, location, creator
            FROM events
            WHERE school = ? AND DATE(date) >= ?
        ''', ('Malcom White Elementary School', current_date))
        malcolmwhite_events = cur.fetchall()
    # Send information for displaying in malcolmwhite.html
    return render_template("malcolm-white.html", data=malcolmwhite_data, events=malcolmwhite_events)

@app.route("/shamrock.html")
def shamrock():
    # Fetch student and parent data for Malcolm White Elementary School
    with connect_db() as con:
        cur = con.cursor()
        cur.execute('''
            SELECT s.first_last_name AS student_name, s.interests AS student_interests,
                   s.grade AS student_grade, s.teacher AS student_teacher, s.school AS student_school,
                   p.first_last_name AS parent_name, p.email AS parent_email, p.phone_number AS parent_phone
            FROM Student s
            JOIN Parent p ON s.parent_id = p.id
            WHERE s.school = ?
        ''', ('Shamrock Elementary School',))
        shamrock_data = cur.fetchall()
        # Fetch events information for Shamrock Elementary School
        cur.execute('''
            SELECT id, name, date, time, location, creator
            FROM events
            WHERE school = ? AND DATE(date) >= ?
        ''', ('Shamrock Elementary School', current_date))
        shamrock_events = cur.fetchall()
    # Send information for displaying in shamrock.html
    return render_template("shamrock.html", data=shamrock_data, events=shamrock_events)

@app.route("/create_event", methods=["POST"])
def create_event():

    if request.method == "POST":
        # Get event details from the form
        event_name = request.form.get("eventName")
        event_date = request.form.get("eventDate")
        event_time = request.form.get("eventTime")
        event_location = request.form.get("eventLocation")
        event_creator = request.form.get("eventCreator")
        event_school = request.form.get("eventSchool")

        # Insert the event details into the events table
        with connect_db() as con:
            cur = con.cursor()
            cur.execute('''
                INSERT INTO events (name, date, time, location, creator, school)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (event_name, event_date, event_time, event_location, event_creator, event_school))

        school_html_mapping = {
            'Goodyear Elementary School': 'goodyear',
            'Hurld Wyman Elementary': 'hurld',
            'Malcolm White Elementary School': 'malcolmwhite',
            'Shamrock Elementary School': 'shamrock',
        }
        selected_school_html = school_html_mapping.get(event_school)
        return redirect(url_for(selected_school_html))

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))



